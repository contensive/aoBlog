The Blog collection creates a blog widget that can be added to any page.

## How to Create a Blog on a website

## How to Add a Blog Post to the website Blog

## Developer

## Resources


